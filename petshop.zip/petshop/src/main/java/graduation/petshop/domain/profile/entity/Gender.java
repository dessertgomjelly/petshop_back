package graduation.petshop.domain.profile.entity;

public enum Gender {
    FEMALE, MALE
}
