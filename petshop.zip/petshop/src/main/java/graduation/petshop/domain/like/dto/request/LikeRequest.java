package graduation.petshop.domain.like.dto.request;

import lombok.Getter;

@Getter
public class LikeRequest {
    private Long memberId;
    private Long boardId;
}
