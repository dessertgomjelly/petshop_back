package graduation.petshop.domain.waltkmate.entity;

public enum SexType {
    MALE,
    FEMALE;
}
