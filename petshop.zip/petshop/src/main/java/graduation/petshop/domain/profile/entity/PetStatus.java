package graduation.petshop.domain.profile.entity;

public enum PetStatus {
    PETYES, PETNO
}
