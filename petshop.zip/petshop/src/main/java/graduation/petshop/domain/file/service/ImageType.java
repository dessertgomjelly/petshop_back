package graduation.petshop.domain.file.service;

public enum ImageType {
    USER_PROFILE,
    BOARD,
    PRODUCT
}
