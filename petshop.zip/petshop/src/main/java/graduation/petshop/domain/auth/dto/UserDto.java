package graduation.petshop.domain.auth.dto;

import lombok.Data;


/**
 * 일단 안 씀
 */
@Data
public class UserDto {

    private String role;
    private String name;
    private String username;
}
